'use strict';

const certnetcontract = require('./contract.js');
module.exports.contracts = [certnetcontract];
